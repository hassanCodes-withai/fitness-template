import { 
  exercises, 
  muscleGroups, 
  equipment, 
  workouts,
  type Exercise, 
  type InsertExercise, 
  type MuscleGroup, 
  type InsertMuscleGroup,
  type Equipment,
  type InsertEquipment,
  type Workout,
  type InsertWorkout
} from "@shared/schema";

export interface IStorage {
  // Exercise methods
  getAllExercises(): Promise<Exercise[]>;
  getExerciseById(id: number): Promise<Exercise | undefined>;
  getExercisesByMuscleGroup(muscleGroup: string): Promise<Exercise[]>;
  getExercisesByEquipment(equipment: string): Promise<Exercise[]>;
  searchExercises(query: string): Promise<Exercise[]>;
  createExercise(exercise: InsertExercise): Promise<Exercise>;
  
  // Muscle group methods
  getAllMuscleGroups(): Promise<MuscleGroup[]>;
  getMuscleGroupById(id: number): Promise<MuscleGroup | undefined>;
  createMuscleGroup(muscleGroup: InsertMuscleGroup): Promise<MuscleGroup>;
  
  // Equipment methods
  getAllEquipment(): Promise<Equipment[]>;
  getEquipmentById(id: number): Promise<Equipment | undefined>;
  createEquipment(equipment: InsertEquipment): Promise<Equipment>;
  
  // Workout methods
  getAllWorkouts(): Promise<Workout[]>;
  getWorkoutById(id: number): Promise<Workout | undefined>;
  createWorkout(workout: InsertWorkout): Promise<Workout>;
  generateWorkout(params: {
    duration: number;
    difficulty: string;
    equipmentAvailable: string[];
    targetMuscles: string[];
    workoutType: string;
  }): Promise<Workout>;
}

export class MemStorage implements IStorage {
  private exercises: Map<number, Exercise>;
  private muscleGroups: Map<number, MuscleGroup>;
  private equipment: Map<number, Equipment>;
  private workouts: Map<number, Workout>;
  private currentExerciseId: number;
  private currentMuscleGroupId: number;
  private currentEquipmentId: number;
  private currentWorkoutId: number;

  constructor() {
    this.exercises = new Map();
    this.muscleGroups = new Map();
    this.equipment = new Map();
    this.workouts = new Map();
    this.currentExerciseId = 1;
    this.currentMuscleGroupId = 1;
    this.currentEquipmentId = 1;
    this.currentWorkoutId = 1;
    
    this.seedData();
  }

  private seedData() {
    // Seed muscle groups
    const muscleGroupData = [
      { name: "Chest", category: "upper", bodyRegion: "chest" },
      { name: "Back", category: "upper", bodyRegion: "back" },
      { name: "Shoulders", category: "upper", bodyRegion: "shoulders" },
      { name: "Biceps", category: "upper", bodyRegion: "arms" },
      { name: "Triceps", category: "upper", bodyRegion: "arms" },
      { name: "Forearms", category: "upper", bodyRegion: "arms" },
      { name: "Abs", category: "core", bodyRegion: "abs" },
      { name: "Obliques", category: "core", bodyRegion: "abs" },
      { name: "Quadriceps", category: "lower", bodyRegion: "legs" },
      { name: "Hamstrings", category: "lower", bodyRegion: "legs" },
      { name: "Glutes", category: "lower", bodyRegion: "glutes" },
      { name: "Calves", category: "lower", bodyRegion: "calves" },
    ];

    muscleGroupData.forEach(data => {
      const id = this.currentMuscleGroupId++;
      const muscleGroup: MuscleGroup = { ...data, id };
      this.muscleGroups.set(id, muscleGroup);
    });

    // Seed equipment
    const equipmentData = [
      { name: "Bodyweight", category: "none", icon: "fas fa-user" },
      { name: "Dumbbells", category: "free_weights", icon: "fas fa-dumbbell" },
      { name: "Barbells", category: "free_weights", icon: "fas fa-weight-hanging" },
      { name: "Machine", category: "machines", icon: "fas fa-cogs" },
      { name: "Kettlebells", category: "free_weights", icon: "fas fa-kettlebell" },
      { name: "Cables", category: "machines", icon: "fas fa-link" },
      { name: "Resistance Bands", category: "accessories", icon: "fas fa-circle" },
      { name: "Medicine Ball", category: "accessories", icon: "fas fa-circle" },
      { name: "TRX", category: "accessories", icon: "fas fa-anchor" },
      { name: "Yoga", category: "bodyweight", icon: "fas fa-leaf" },
      { name: "Cardio", category: "cardio", icon: "fas fa-heartbeat" },
      { name: "Smith Machine", category: "machines", icon: "fas fa-industry" },
      { name: "Plate", category: "free_weights", icon: "fas fa-circle" },
      { name: "Bosu Ball", category: "accessories", icon: "fas fa-circle-half-stroke" },
      { name: "Stretches", category: "flexibility", icon: "fas fa-expand-arrows-alt" },
    ];

    equipmentData.forEach(data => {
      const id = this.currentEquipmentId++;
      const equipment: Equipment = { 
        ...data, 
        id,
        icon: data.icon || null
      };
      this.equipment.set(id, equipment);
    });

    // Seed exercises
    const exerciseData = [
      {
        name: "Push-up",
        description: "A fundamental upper body exercise targeting chest, shoulders, and triceps.",
        instructions: ["Start in a plank position with hands placed slightly wider than shoulder-width apart.", "Lower your body until your chest nearly touches the floor.", "Push yourself back up to the starting position.", "Repeat for desired number of repetitions."],
        primaryMuscles: ["Chest", "Triceps"],
        secondaryMuscles: ["Shoulders", "Abs"],
        equipment: "Bodyweight",
        difficulty: "Beginner",
        exerciseType: "Compound",
        videoUrl: null,
        thumbnailUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
      },
      {
        name: "Squat",
        description: "Essential lower body exercise for quadriceps, glutes, and hamstrings.",
        instructions: ["Stand with feet shoulder-width apart.", "Lower your body by bending at the hips and knees.", "Keep your chest up and weight on your heels.", "Return to standing position."],
        primaryMuscles: ["Quadriceps", "Glutes"],
        secondaryMuscles: ["Hamstrings", "Abs"],
        equipment: "Bodyweight",
        difficulty: "Beginner",
        exerciseType: "Compound",
        videoUrl: null,
        thumbnailUrl: "https://images.unsplash.com/photo-1574680096145-d05b474e2155?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
      },
      {
        name: "Deadlift",
        description: "Compound movement for posterior chain strength and muscle development.",
        instructions: ["Stand with feet hip-width apart, bar over mid-foot.", "Bend at hips and knees to grip the bar.", "Keep back straight and chest up.", "Drive through heels to lift the bar."],
        primaryMuscles: ["Back", "Glutes"],
        secondaryMuscles: ["Hamstrings", "Forearms"],
        equipment: "Barbells",
        difficulty: "Intermediate",
        exerciseType: "Compound",
        videoUrl: null,
        thumbnailUrl: "https://images.unsplash.com/photo-1434682772747-f16d3ea162c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
      },
      {
        name: "Pull-up",
        description: "Upper body pulling exercise for back, biceps, and grip strength.",
        instructions: ["Hang from a pull-up bar with arms fully extended.", "Pull your body up until your chin is over the bar.", "Lower yourself back to the starting position.", "Repeat for desired reps."],
        primaryMuscles: ["Back", "Biceps"],
        secondaryMuscles: ["Shoulders", "Forearms"],
        equipment: "Bodyweight",
        difficulty: "Advanced",
        exerciseType: "Compound",
        videoUrl: null,
        thumbnailUrl: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
      },
      {
        name: "Overhead Press",
        description: "Vertical pressing movement for shoulder and tricep development.",
        instructions: ["Stand with feet shoulder-width apart, holding dumbbells at shoulder height.", "Press the weights overhead until arms are fully extended.", "Lower the weights back to shoulder height.", "Repeat for desired repetitions."],
        primaryMuscles: ["Shoulders", "Triceps"],
        secondaryMuscles: ["Abs", "Upper Back"],
        equipment: "Dumbbells",
        difficulty: "Intermediate",
        exerciseType: "Compound",
        videoUrl: null,
        thumbnailUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
      },
      {
        name: "Plank",
        description: "Isometric core exercise for stability and endurance.",
        instructions: ["Start in a push-up position but rest on your forearms.", "Keep your body in a straight line from head to heels.", "Engage your core and hold the position.", "Breathe normally while maintaining the position."],
        primaryMuscles: ["Abs", "Obliques"],
        secondaryMuscles: ["Shoulders", "Back"],
        equipment: "Bodyweight",
        difficulty: "Beginner",
        exerciseType: "Isolation",
        videoUrl: null,
        thumbnailUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
      },
      {
        name: "Lunge",
        description: "Unilateral leg exercise for balance and lower body strength.",
        instructions: ["Stand with feet hip-width apart.", "Step forward with one leg and lower your hips.", "Keep your front knee over your ankle.", "Push back to the starting position and repeat."],
        primaryMuscles: ["Quadriceps", "Glutes"],
        secondaryMuscles: ["Hamstrings", "Calves"],
        equipment: "Bodyweight",
        difficulty: "Beginner",
        exerciseType: "Compound",
        videoUrl: null,
        thumbnailUrl: "https://images.unsplash.com/photo-1599058917212-d750089bc07e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
      },
      {
        name: "Dips",
        description: "Compound pushing exercise targeting triceps and chest muscles.",
        instructions: ["Position yourself on parallel bars or between two stable surfaces.", "Lower your body by bending your elbows.", "Keep your body upright and elbows close to your sides.", "Push back up to the starting position."],
        primaryMuscles: ["Triceps", "Chest"],
        secondaryMuscles: ["Shoulders", "Abs"],
        equipment: "Bodyweight",
        difficulty: "Intermediate",
        exerciseType: "Compound",
        videoUrl: null,
        thumbnailUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
      }
    ];

    exerciseData.forEach(data => {
      const id = this.currentExerciseId++;
      const exercise: Exercise = { 
        ...data, 
        id,
        videoUrl: data.videoUrl || null,
        thumbnailUrl: data.thumbnailUrl || null
      };
      this.exercises.set(id, exercise);
    });
  }

  async getAllExercises(): Promise<Exercise[]> {
    return Array.from(this.exercises.values());
  }

  async getExerciseById(id: number): Promise<Exercise | undefined> {
    return this.exercises.get(id);
  }

  async getExercisesByMuscleGroup(muscleGroup: string): Promise<Exercise[]> {
    return Array.from(this.exercises.values()).filter(exercise => 
      (exercise.primaryMuscles as string[]).includes(muscleGroup) ||
      (exercise.secondaryMuscles as string[]).includes(muscleGroup)
    );
  }

  async getExercisesByEquipment(equipment: string): Promise<Exercise[]> {
    return Array.from(this.exercises.values()).filter(exercise => 
      exercise.equipment === equipment
    );
  }

  async searchExercises(query: string): Promise<Exercise[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.exercises.values()).filter(exercise =>
      exercise.name.toLowerCase().includes(lowercaseQuery) ||
      exercise.description.toLowerCase().includes(lowercaseQuery) ||
      (exercise.primaryMuscles as string[]).some(muscle => 
        muscle.toLowerCase().includes(lowercaseQuery)
      )
    );
  }

  async createExercise(insertExercise: InsertExercise): Promise<Exercise> {
    const id = this.currentExerciseId++;
    const exercise: Exercise = { 
      ...insertExercise, 
      id,
      videoUrl: insertExercise.videoUrl ?? null,
      thumbnailUrl: insertExercise.thumbnailUrl ?? null
    };
    this.exercises.set(id, exercise);
    return exercise;
  }

  async getAllMuscleGroups(): Promise<MuscleGroup[]> {
    return Array.from(this.muscleGroups.values());
  }

  async getMuscleGroupById(id: number): Promise<MuscleGroup | undefined> {
    return this.muscleGroups.get(id);
  }

  async createMuscleGroup(insertMuscleGroup: InsertMuscleGroup): Promise<MuscleGroup> {
    const id = this.currentMuscleGroupId++;
    const muscleGroup: MuscleGroup = { ...insertMuscleGroup, id };
    this.muscleGroups.set(id, muscleGroup);
    return muscleGroup;
  }

  async getAllEquipment(): Promise<Equipment[]> {
    return Array.from(this.equipment.values());
  }

  async getEquipmentById(id: number): Promise<Equipment | undefined> {
    return this.equipment.get(id);
  }

  async createEquipment(insertEquipment: InsertEquipment): Promise<Equipment> {
    const id = this.currentEquipmentId++;
    const equipment: Equipment = { 
      ...insertEquipment, 
      id,
      icon: insertEquipment.icon ?? null
    };
    this.equipment.set(id, equipment);
    return equipment;
  }

  async getAllWorkouts(): Promise<Workout[]> {
    return Array.from(this.workouts.values());
  }

  async getWorkoutById(id: number): Promise<Workout | undefined> {
    return this.workouts.get(id);
  }

  async createWorkout(insertWorkout: InsertWorkout): Promise<Workout> {
    const id = this.currentWorkoutId++;
    const workout: Workout = { 
      ...insertWorkout, 
      id,
      description: insertWorkout.description ?? null
    };
    this.workouts.set(id, workout);
    return workout;
  }

  async generateWorkout(params: {
    duration: number;
    difficulty: string;
    equipmentAvailable: string[];
    targetMuscles: string[];
    workoutType: string;
  }): Promise<Workout> {
    // Filter exercises based on parameters
    const availableExercises = Array.from(this.exercises.values()).filter(exercise => {
      const hasEquipment = params.equipmentAvailable.includes(exercise.equipment);
      const matchesDifficulty = exercise.difficulty === params.difficulty;
      const targetsDesiredMuscles = params.targetMuscles.length === 0 || 
        params.targetMuscles.some(muscle => 
          (exercise.primaryMuscles as string[]).includes(muscle)
        );
      
      return hasEquipment && matchesDifficulty && targetsDesiredMuscles;
    });

    // Select exercises for workout (simplified algorithm)
    const exercisesPerMuscle = Math.max(1, Math.floor(params.duration / 10));
    const selectedExercises: Exercise[] = [];
    
    if (params.targetMuscles.length > 0) {
      params.targetMuscles.forEach(muscle => {
        const muscleExercises = availableExercises.filter(ex => 
          (ex.primaryMuscles as string[]).includes(muscle)
        ).slice(0, exercisesPerMuscle);
        selectedExercises.push(...muscleExercises);
      });
    } else {
      selectedExercises.push(...availableExercises.slice(0, exercisesPerMuscle * 3));
    }

    const workout: Workout = {
      id: this.currentWorkoutId++,
      name: `Custom ${params.workoutType} Workout`,
      description: `Generated ${params.difficulty.toLowerCase()} ${params.workoutType.toLowerCase()} workout` as string | null,
      duration: params.duration,
      difficulty: params.difficulty,
      targetMuscles: params.targetMuscles,
      equipmentNeeded: params.equipmentAvailable,
      exerciseIds: selectedExercises.map(ex => ex.id),
      workoutType: params.workoutType
    };

    this.workouts.set(workout.id, workout);
    return workout;
  }
}

export const storage = new MemStorage();
