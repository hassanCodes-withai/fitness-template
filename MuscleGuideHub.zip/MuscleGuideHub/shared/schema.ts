import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const exercises = pgTable("exercises", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  instructions: jsonb("instructions").notNull(), // array of step-by-step instructions
  primaryMuscles: jsonb("primary_muscles").notNull(), // array of muscle group names
  secondaryMuscles: jsonb("secondary_muscles").notNull(), // array of muscle group names
  equipment: text("equipment").notNull(),
  difficulty: text("difficulty").notNull(), // "Beginner", "Intermediate", "Advanced"
  exerciseType: text("exercise_type").notNull(), // "Compound", "Isolation", "Cardio"
  videoUrl: text("video_url"), // placeholder for branded video upload
  thumbnailUrl: text("thumbnail_url"), // placeholder for exercise thumbnail
});

export const muscleGroups = pgTable("muscle_groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category").notNull(), // "upper", "lower", "core"
  bodyRegion: text("body_region").notNull(), // for body map positioning
});

export const equipment = pgTable("equipment", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category").notNull(),
  icon: text("icon"), // icon class name
});

export const workouts = pgTable("workouts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  duration: integer("duration").notNull(), // in minutes
  difficulty: text("difficulty").notNull(),
  targetMuscles: jsonb("target_muscles").notNull(), // array of muscle group names
  equipmentNeeded: jsonb("equipment_needed").notNull(), // array of equipment names
  exerciseIds: jsonb("exercise_ids").notNull(), // array of exercise IDs
  workoutType: text("workout_type").notNull(), // "Strength", "Cardio", "Flexibility"
});

export const insertExerciseSchema = createInsertSchema(exercises).omit({
  id: true,
});

export const insertMuscleGroupSchema = createInsertSchema(muscleGroups).omit({
  id: true,
});

export const insertEquipmentSchema = createInsertSchema(equipment).omit({
  id: true,
});

export const insertWorkoutSchema = createInsertSchema(workouts).omit({
  id: true,
});

export type Exercise = typeof exercises.$inferSelect;
export type InsertExercise = z.infer<typeof insertExerciseSchema>;
export type MuscleGroup = typeof muscleGroups.$inferSelect;
export type InsertMuscleGroup = z.infer<typeof insertMuscleGroupSchema>;
export type Equipment = typeof equipment.$inferSelect;
export type InsertEquipment = z.infer<typeof insertEquipmentSchema>;
export type Workout = typeof workouts.$inferSelect;
export type InsertWorkout = z.infer<typeof insertWorkoutSchema>;
