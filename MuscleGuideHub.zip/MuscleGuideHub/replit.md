# MuscleWiki Exercise Database Application

## Overview

This is a full-stack exercise database application built with React, TypeScript, Express.js, and PostgreSQL. The application provides a comprehensive platform for browsing exercises, searching by muscle groups and equipment, and generating personalized workouts. It features an interactive body map for visual muscle group selection and a modern, responsive design built with shadcn/ui components.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Full-Stack Architecture
The application follows a modern full-stack architecture with a clear separation between client and server:

- **Frontend**: React 18 with TypeScript, using Vite as the build tool
- **Backend**: Node.js with Express.js server
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Deployment**: Configured for Replit hosting with development and production environments

### Monorepo Structure
The codebase is organized as a monorepo with shared types and schemas:
- `client/` - React frontend application
- `server/` - Express.js backend API
- `shared/` - Shared TypeScript types and database schemas

## Key Components

### Frontend Architecture
- **React Router**: Uses Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **API Design**: RESTful API with Express.js
- **Database Layer**: Drizzle ORM with PostgreSQL, using Neon serverless database
- **Validation**: Zod schemas for request/response validation
- **Error Handling**: Centralized error handling middleware
- **Logging**: Request logging with response time tracking

### Database Schema
The database includes four main entities:
- **Exercises**: Core exercise data with instructions, muscle groups, equipment, and difficulty
- **Muscle Groups**: Categorized muscle group definitions for body mapping
- **Equipment**: Equipment categories and types for filtering
- **Workouts**: Generated workout plans with exercise combinations

## Data Flow

### Exercise Browsing Flow
1. User selects muscle group via interactive body map or sidebar filters
2. Frontend queries `/api/exercises` with filter parameters
3. Backend retrieves filtered exercises from database
4. Results displayed in grid or list view with exercise cards

### Workout Generation Flow
1. User inputs preferences (duration, difficulty, equipment, target muscles)
2. Frontend posts to `/api/workouts/generate` with parameters
3. Backend algorithm selects appropriate exercises based on criteria
4. Generated workout stored and returned to user

### Search and Filtering
- Real-time search through exercise names and descriptions
- Multi-dimensional filtering by muscle group, equipment, and difficulty
- Debounced search queries to optimize performance

## External Dependencies

### Core Technologies
- **React 18**: Modern React with hooks and concurrent features
- **TypeScript**: Full type safety across client and server
- **Vite**: Fast build tool with HMR for development
- **Express.js**: Minimal web framework for Node.js

### Database and ORM
- **PostgreSQL**: Primary database via Neon serverless
- **Drizzle ORM**: Type-safe database queries and migrations
- **Drizzle-Zod**: Automatic schema validation generation

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework
- **Radix UI**: Headless UI components for accessibility
- **shadcn/ui**: Pre-built component library
- **Lucide React**: Icon library

### Development Tools
- **TanStack Query**: Server state management and caching
- **Wouter**: Lightweight React router
- **date-fns**: Date manipulation utilities
- **clsx**: Conditional CSS class utilities

## Deployment Strategy

### Development Environment
- **Vite Dev Server**: Hot module replacement for fast development
- **Express Middleware**: Vite integrated with Express in development
- **Environment Variables**: DATABASE_URL for database connection
- **TypeScript Compilation**: Incremental compilation with tsc

### Production Build
- **Frontend Build**: Vite builds optimized static assets to `dist/public`
- **Backend Build**: ESBuild bundles server code to `dist/index.js`
- **Static Serving**: Express serves built React app in production
- **Database Migrations**: Drizzle handles schema migrations

### Replit Integration
- **Development Banner**: Replit development environment detection
- **Runtime Error Overlay**: Enhanced error reporting in development
- **Cartographer Plugin**: Replit-specific development tools
- **Environment Detection**: Conditional plugin loading based on REPL_ID

The application is designed for easy deployment on Replit with automatic detection of the hosting environment and appropriate configuration for both development and production scenarios.