import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { ArrowLeft, Play, Clock, Target, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/header";
import type { Exercise } from "@shared/schema";

export default function ExerciseDetail() {
  const { id } = useParams();
  
  const { data: exercise, isLoading } = useQuery<Exercise>({
    queryKey: ["/api/exercises", id],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Header searchQuery="" onSearchChange={() => {}} />
        <div className="max-w-4xl mx-auto pt-8 px-4">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-64 mb-4" />
            <div className="grid md:grid-cols-2 gap-8">
              <div className="h-64 bg-slate-200 rounded" />
              <div className="space-y-4">
                <div className="h-4 bg-slate-200 rounded w-3/4" />
                <div className="h-4 bg-slate-200 rounded w-1/2" />
                <div className="h-4 bg-slate-200 rounded w-2/3" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!exercise) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Header searchQuery="" onSearchChange={() => {}} />
        <div className="max-w-4xl mx-auto pt-8 px-4">
          <div className="text-center py-12">
            <h1 className="text-2xl font-bold text-slate-900 mb-4">Exercise not found</h1>
            <Link href="/">
              <Button>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800";
      case "Intermediate": return "bg-orange-100 text-orange-800";
      case "Advanced": return "bg-red-100 text-red-800";
      default: return "bg-slate-100 text-slate-800";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header searchQuery="" onSearchChange={() => {}} />
      
      <div className="max-w-4xl mx-auto pt-8 px-4 pb-16">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Exercises
            </Button>
          </Link>
          
          <div className="flex flex-wrap items-center gap-4 mb-4">
            <h1 className="text-3xl font-bold text-slate-900">{exercise.name}</h1>
            <div className="flex gap-2">
              {(exercise.primaryMuscles as string[]).map((muscle) => (
                <Badge key={muscle} variant="secondary">
                  {muscle}
                </Badge>
              ))}
              <Badge className={getDifficultyColor(exercise.difficulty)}>
                {exercise.difficulty}
              </Badge>
            </div>
          </div>
          
          <p className="text-slate-600 text-lg">{exercise.description}</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Video Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play className="h-5 w-5" />
                Exercise Video
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-slate-100 rounded-lg aspect-video flex items-center justify-center border-2 border-dashed border-slate-300">
                <div className="text-center">
                  <Play className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-600 font-medium">Video Placeholder</p>
                  <p className="text-sm text-slate-500 mt-2">
                    Upload your branded tutorial video here
                  </p>
                </div>
              </div>
              
              {exercise.thumbnailUrl && (
                <img 
                  src={exercise.thumbnailUrl} 
                  alt={`${exercise.name} thumbnail`}
                  className="w-full h-48 object-cover rounded-lg mt-4"
                />
              )}
            </CardContent>
          </Card>

          {/* Instructions Section */}
          <Card>
            <CardHeader>
              <CardTitle>Instructions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {(exercise.instructions as string[]).map((instruction, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium mt-0.5 flex-shrink-0">
                      {index + 1}
                    </div>
                    <p className="text-slate-700">{instruction}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Exercise Details */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Exercise Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <Target className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                <h4 className="font-semibold text-slate-900 mb-1">Primary Muscles</h4>
                <p className="text-sm text-slate-600">
                  {(exercise.primaryMuscles as string[]).join(", ")}
                </p>
              </div>
              
              <div className="text-center">
                <Target className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                <h4 className="font-semibold text-slate-900 mb-1">Secondary Muscles</h4>
                <p className="text-sm text-slate-600">
                  {(exercise.secondaryMuscles as string[]).join(", ")}
                </p>
              </div>
              
              <div className="text-center">
                <Settings className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                <h4 className="font-semibold text-slate-900 mb-1">Equipment</h4>
                <p className="text-sm text-slate-600">{exercise.equipment}</p>
              </div>
              
              <div className="text-center">
                <Clock className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                <h4 className="font-semibold text-slate-900 mb-1">Exercise Type</h4>
                <p className="text-sm text-slate-600">{exercise.exerciseType}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
