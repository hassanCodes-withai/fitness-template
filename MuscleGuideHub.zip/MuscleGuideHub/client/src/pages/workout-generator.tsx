import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Dumbbell, Heart, Zap } from "lucide-react";
import Header from "@/components/header";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Equipment, Workout } from "@shared/schema";

export default function WorkoutGenerator() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [workoutType, setWorkoutType] = useState<string>("Strength");
  const [experience, setExperience] = useState<string>("Beginner");
  const [duration, setDuration] = useState<string>("30");
  const [selectedEquipment, setSelectedEquipment] = useState<string[]>([]);
  const [targetMuscles, setTargetMuscles] = useState<string[]>([]);

  const { data: equipment = [] } = useQuery<Equipment[]>({
    queryKey: ["/api/equipment"],
  });

  const generateWorkoutMutation = useMutation({
    mutationFn: async (params: {
      workoutType: string;
      difficulty: string;
      duration: number;
      equipmentAvailable: string[];
      targetMuscles: string[];
    }) => {
      const response = await apiRequest("POST", "/api/workouts/generate", params);
      return response.json();
    },
    onSuccess: (workout: Workout) => {
      toast({
        title: "Workout Generated!",
        description: `Your ${workout.name} is ready with ${(workout.exerciseIds as number[]).length} exercises.`,
      });
      setLocation("/");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate workout. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEquipmentChange = (equipmentName: string, checked: boolean) => {
    if (checked) {
      setSelectedEquipment([...selectedEquipment, equipmentName]);
    } else {
      setSelectedEquipment(selectedEquipment.filter(eq => eq !== equipmentName));
    }
  };

  const handleMuscleChange = (muscle: string, checked: boolean) => {
    if (checked) {
      setTargetMuscles([...targetMuscles, muscle]);
    } else {
      setTargetMuscles(targetMuscles.filter(m => m !== muscle));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (selectedEquipment.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one piece of equipment.",
        variant: "destructive",
      });
      return;
    }

    generateWorkoutMutation.mutate({
      workoutType,
      difficulty: experience,
      duration: parseInt(duration),
      equipmentAvailable: selectedEquipment,
      targetMuscles,
    });
  };

  const muscleGroups = [
    "Chest", "Back", "Shoulders", "Biceps", "Triceps", 
    "Abs", "Quadriceps", "Hamstrings", "Glutes", "Calves"
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Header searchQuery="" onSearchChange={() => {}} />
      
      <div className="max-w-2xl mx-auto pt-8 px-4 pb-16">
        <div className="mb-6">
          <Button variant="ghost" className="mb-4" onClick={() => setLocation("/")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
          
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Workout Generator</h1>
          <p className="text-slate-600">
            Create a personalized workout based on your preferences and available equipment.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Let's Get Started</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Workout Type */}
              <div>
                <Label className="text-base font-semibold mb-4 block">Workout Type</Label>
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    type="button"
                    variant={workoutType === "Strength" ? "default" : "outline"}
                    className="h-16 flex-col gap-2"
                    onClick={() => setWorkoutType("Strength")}
                  >
                    <Dumbbell className="h-6 w-6" />
                    Strength Training
                  </Button>
                  <Button
                    type="button"
                    variant={workoutType === "Cardio" ? "default" : "outline"}
                    className="h-16 flex-col gap-2"
                    onClick={() => setWorkoutType("Cardio")}
                  >
                    <Heart className="h-6 w-6" />
                    Cardio
                  </Button>
                </div>
              </div>

              {/* Experience Level */}
              <div>
                <Label htmlFor="experience" className="text-base font-semibold mb-3 block">
                  Experience Level
                </Label>
                <Select value={experience} onValueChange={setExperience}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Beginner">Beginner</SelectItem>
                    <SelectItem value="Intermediate">Intermediate</SelectItem>
                    <SelectItem value="Advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Workout Duration */}
              <div>
                <Label className="text-base font-semibold mb-4 block">Workout Duration</Label>
                <div className="grid grid-cols-3 gap-3">
                  {["30", "45", "60"].map((time) => (
                    <Button
                      key={time}
                      type="button"
                      variant={duration === time ? "default" : "outline"}
                      onClick={() => setDuration(time)}
                    >
                      {time} min
                    </Button>
                  ))}
                </div>
              </div>

              {/* Equipment */}
              <div>
                <Label className="text-base font-semibold mb-4 block">Available Equipment</Label>
                <div className="grid grid-cols-2 gap-3 max-h-48 overflow-y-auto">
                  {equipment.map((eq) => (
                    <div key={eq.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`equipment-${eq.id}`}
                        checked={selectedEquipment.includes(eq.name)}
                        onCheckedChange={(checked) => 
                          handleEquipmentChange(eq.name, checked as boolean)
                        }
                      />
                      <Label 
                        htmlFor={`equipment-${eq.id}`}
                        className="text-sm font-normal cursor-pointer"
                      >
                        {eq.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Target Muscle Groups */}
              <div>
                <Label className="text-base font-semibold mb-4 block">
                  Target Muscle Groups (Optional)
                </Label>
                <div className="grid grid-cols-2 gap-3">
                  {muscleGroups.map((muscle) => (
                    <div key={muscle} className="flex items-center space-x-2">
                      <Checkbox
                        id={`muscle-${muscle}`}
                        checked={targetMuscles.includes(muscle)}
                        onCheckedChange={(checked) => 
                          handleMuscleChange(muscle, checked as boolean)
                        }
                      />
                      <Label 
                        htmlFor={`muscle-${muscle}`}
                        className="text-sm font-normal cursor-pointer"
                      >
                        {muscle}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Generate Button */}
              <Button 
                type="submit" 
                className="w-full h-12 bg-orange-500 hover:bg-orange-600"
                disabled={generateWorkoutMutation.isPending}
              >
                {generateWorkoutMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Zap className="mr-2 h-5 w-5" />
                    Generate My Workout
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
