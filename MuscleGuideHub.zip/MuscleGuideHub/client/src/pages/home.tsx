import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import Sidebar from "@/components/sidebar";
import InteractiveBodyMap from "@/components/interactive-body-map";
import ExerciseCard from "@/components/exercise-card";
import { useIsMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Grid, List } from "lucide-react";
import type { Exercise } from "@shared/schema";

export default function Home() {
  const [selectedMuscle, setSelectedMuscle] = useState<string>("");
  const [selectedEquipment, setSelectedEquipment] = useState<string>("Featured");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [difficultyFilter, setDifficultyFilter] = useState<string>("all");
  const isMobile = useIsMobile();

  const { data: exercises = [], isLoading } = useQuery<Exercise[]>({
    queryKey: ["/api/exercises", { 
      muscleGroup: selectedMuscle, 
      equipment: selectedEquipment === "Featured" ? undefined : selectedEquipment,
      search: searchQuery 
    }],
  });

  const filteredExercises = exercises.filter(exercise => {
    if (difficultyFilter !== "all" && exercise.difficulty !== difficultyFilter) {
      return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-background dark:bg-background">
      <Header searchQuery={searchQuery} onSearchChange={setSearchQuery} />
      
      <div className="flex max-w-7xl mx-auto">
        {!isMobile && (
          <Sidebar 
            selectedEquipment={selectedEquipment}
            onEquipmentChange={setSelectedEquipment}
          />
        )}
        
        <main className="flex-1 p-6">
          {/* Interactive Body Map Section */}
          <div className="bg-card dark:bg-card rounded-xl shadow-sm border border-border p-8 mb-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground dark:text-foreground mb-2">
                Click on any muscle to get started
              </h2>
              <p className="text-muted-foreground dark:text-muted-foreground">
                Select a muscle group to view targeted exercises
              </p>
            </div>
            
            <InteractiveBodyMap 
              selectedMuscle={selectedMuscle}
              onMuscleSelect={setSelectedMuscle}
            />
          </div>

          {/* Exercise Library Section */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-900">
                {selectedMuscle ? `${selectedMuscle} Exercises` : 
                 selectedEquipment === "Featured" ? "Featured Exercises" : 
                 `${selectedEquipment} Exercises`}
              </h3>
              
              <div className="flex items-center space-x-4">
                <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Difficulties</SelectItem>
                    <SelectItem value="Beginner">Beginner</SelectItem>
                    <SelectItem value="Intermediate">Intermediate</SelectItem>
                    <SelectItem value="Advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
                
                <div className="flex space-x-2">
                  <Button
                    variant={viewMode === "grid" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="bg-slate-100 rounded-lg h-80 animate-pulse" />
                ))}
              </div>
            ) : filteredExercises.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-slate-600 text-lg">
                  No exercises found. Try adjusting your filters.
                </p>
              </div>
            ) : (
              <div className={`grid gap-6 ${
                viewMode === "grid" 
                  ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
                  : "grid-cols-1"
              }`}>
                {filteredExercises.map((exercise) => (
                  <ExerciseCard 
                    key={exercise.id} 
                    exercise={exercise} 
                    viewMode={viewMode}
                  />
                ))}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Mobile Navigation */}
      {isMobile && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 p-4">
          <div className="flex justify-around">
            <button className="flex flex-col items-center space-y-1 text-primary">
              <i className="fas fa-home text-lg"></i>
              <span className="text-xs font-medium">Home</span>
            </button>
            <button className="flex flex-col items-center space-y-1 text-slate-600">
              <i className="fas fa-search text-lg"></i>
              <span className="text-xs font-medium">Search</span>
            </button>
            <button className="flex flex-col items-center space-y-1 text-slate-600">
              <i className="fas fa-dumbbell text-lg"></i>
              <span className="text-xs font-medium">Exercises</span>
            </button>
            <button className="flex flex-col items-center space-y-1 text-slate-600">
              <i className="fas fa-user text-lg"></i>
              <span className="text-xs font-medium">Profile</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
