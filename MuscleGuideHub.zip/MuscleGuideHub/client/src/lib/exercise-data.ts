// This file contains utility functions for exercise data manipulation

export const muscleGroupColors = {
  "Chest": "hsl(0, 84%, 60%)",
  "Back": "hsl(240, 84%, 60%)",
  "Shoulders": "hsl(120, 84%, 60%)",
  "Biceps": "hsl(60, 84%, 60%)",
  "Triceps": "hsl(60, 84%, 60%)",
  "Forearms": "hsl(60, 84%, 60%)",
  "Abs": "hsl(180, 84%, 60%)",
  "Obliques": "hsl(180, 84%, 60%)",
  "Quadriceps": "hsl(280, 84%, 60%)",
  "Hamstrings": "hsl(280, 84%, 60%)",
  "Glutes": "hsl(280, 84%, 60%)",
  "Calves": "hsl(280, 84%, 60%)",
};

export const equipmentCategories = {
  "none": ["Bodyweight"],
  "free_weights": ["Dumbbells", "Barbells", "Kettlebells", "Plate"],
  "machines": ["Machine", "Cables", "Smith Machine"],
  "accessories": ["Medicine Ball", "TRX", "Resistance Bands", "Bosu Ball"],
  "bodyweight": ["Yoga"],
  "cardio": ["Cardio"],
  "flexibility": ["Stretches"],
};

export const difficultyLevels = ["Beginner", "Intermediate", "Advanced"];

export const exerciseTypes = ["Compound", "Isolation", "Cardio", "Flexibility"];

export function getMuscleGroupColor(muscleGroup: string): string {
  return muscleGroupColors[muscleGroup as keyof typeof muscleGroupColors] || "hsl(0, 0%, 50%)";
}

export function getEquipmentCategory(equipment: string): string {
  for (const [category, items] of Object.entries(equipmentCategories)) {
    if (items.includes(equipment)) {
      return category;
    }
  }
  return "other";
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) {
    return `${minutes}m`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

export function getDifficultyIcon(difficulty: string): string {
  switch (difficulty) {
    case "Beginner": return "🟢";
    case "Intermediate": return "🟡";
    case "Advanced": return "🔴";
    default: return "⚪";
  }
}

export function getEquipmentIcon(equipment: string): string {
  const iconMap: Record<string, string> = {
    "Bodyweight": "🤸",
    "Dumbbells": "🏋️",
    "Barbells": "🏋️‍♂️",
    "Machine": "⚙️",
    "Kettlebells": "🎯",
    "Cables": "🔗",
    "Resistance Bands": "🔗",
    "Medicine Ball": "⚽",
    "TRX": "⛓️",
    "Yoga": "🧘",
    "Cardio": "❤️",
    "Smith Machine": "🏭",
    "Plate": "⭕",
    "Bosu Ball": "🔵",
    "Stretches": "🤸‍♀️",
  };
  
  return iconMap[equipment] || "🏃";
}
