import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import type { Equipment } from "@shared/schema";

interface EquipmentFilterProps {
  selectedEquipment: string;
  onEquipmentChange: (equipment: string) => void;
}

export default function EquipmentFilter({ selectedEquipment, onEquipmentChange }: EquipmentFilterProps) {
  const { data: equipment = [] } = useQuery<Equipment[]>({
    queryKey: ["/api/equipment"],
  });

  const featuredEquipment = ["Featured", "Bodyweight", "Dumbbells", "Barbells"];
  const categorizedEquipment = equipment.reduce((acc, eq) => {
    if (!acc[eq.category]) {
      acc[eq.category] = [];
    }
    acc[eq.category].push(eq);
    return acc;
  }, {} as Record<string, Equipment[]>);

  return (
    <div className="space-y-4">
      {/* Featured */}
      <div>
        <h4 className="text-sm font-semibold text-slate-900 mb-2">Featured</h4>
        <div className="space-y-1">
          {featuredEquipment.map((equipmentName) => (
            <Button
              key={equipmentName}
              variant={selectedEquipment === equipmentName ? "secondary" : "ghost"}
              className={`w-full justify-start text-sm font-normal ${
                selectedEquipment === equipmentName 
                  ? "bg-orange-500 text-white hover:bg-orange-600" 
                  : ""
              }`}
              onClick={() => onEquipmentChange(equipmentName)}
            >
              {equipmentName}
            </Button>
          ))}
        </div>
      </div>

      <Separator />

      {/* Categorized Equipment */}
      <ScrollArea className="h-64">
        {Object.entries(categorizedEquipment).map(([category, items]) => (
          <div key={category} className="mb-4">
            <h4 className="text-sm font-semibold text-slate-900 mb-2 capitalize">
              {category.replace("_", " ")}
            </h4>
            <div className="space-y-1">
              {items.map((eq) => (
                <Button
                  key={eq.id}
                  variant={selectedEquipment === eq.name ? "secondary" : "ghost"}
                  className={`w-full justify-start text-sm font-normal ${
                    selectedEquipment === eq.name 
                      ? "bg-orange-500 text-white hover:bg-orange-600" 
                      : ""
                  }`}
                  onClick={() => onEquipmentChange(eq.name)}
                >
                  <i className={`${eq.icon} mr-2`} />
                  {eq.name}
                </Button>
              ))}
            </div>
          </div>
        ))}
      </ScrollArea>
    </div>
  );
}
