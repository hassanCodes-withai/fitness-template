import { Link } from "wouter";
import { Play, Clock, Target } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import type { Exercise } from "@shared/schema";

interface ExerciseCardProps {
  exercise: Exercise;
  viewMode: "grid" | "list";
}

export default function ExerciseCard({ exercise, viewMode }: ExerciseCardProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800";
      case "Intermediate": return "bg-orange-100 text-orange-800";
      case "Advanced": return "bg-red-100 text-red-800";
      default: return "bg-slate-100 text-slate-800";
    }
  };

  const getEquipmentColor = (equipment: string) => {
    switch (equipment) {
      case "Bodyweight": return "bg-red-100 text-red-800";
      case "Dumbbells": return "bg-blue-100 text-blue-800";
      case "Barbells": return "bg-yellow-100 text-yellow-800";
      case "Machine": return "bg-purple-100 text-purple-800";
      default: return "bg-slate-100 text-slate-800";
    }
  };

  if (viewMode === "list") {
    return (
      <Link href={`/exercise/${exercise.id}`}>
        <Card className="exercise-card cursor-pointer">
          <CardContent className="p-4">
            <div className="flex items-center space-x-4">
              {/* Thumbnail */}
              <div className="relative flex-shrink-0">
                <img 
                  src={exercise.thumbnailUrl || "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=100"} 
                  alt={exercise.name}
                  className="w-24 h-16 object-cover rounded-lg"
                />
                <div className="absolute inset-0 bg-black bg-opacity-20 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Play className="h-4 w-4 text-white" />
                </div>
              </div>
              
              {/* Content */}
              <div className="flex-1">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-semibold text-slate-900 mb-1">{exercise.name}</h4>
                    <p className="text-sm text-slate-600 mb-2">{exercise.description}</p>
                    <div className="flex items-center space-x-2">
                      {(exercise.primaryMuscles as string[]).slice(0, 2).map((muscle) => (
                        <Badge key={muscle} variant="secondary" className="text-xs">
                          {muscle}
                        </Badge>
                      ))}
                      <Badge className={`${getEquipmentColor(exercise.equipment)} text-xs`}>
                        {exercise.equipment}
                      </Badge>
                    </div>
                  </div>
                  <Badge className={getDifficultyColor(exercise.difficulty)}>
                    {exercise.difficulty}
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>
    );
  }

  return (
    <Link href={`/exercise/${exercise.id}`}>
      <Card className="exercise-card cursor-pointer overflow-hidden">
        <div className="relative">
          <img 
            src={exercise.thumbnailUrl || "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"} 
            alt={exercise.name}
            className="w-full h-48 object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
            <div className="w-12 h-12 bg-white bg-opacity-90 rounded-full flex items-center justify-center">
              <Play className="h-5 w-5 text-primary ml-1" />
            </div>
          </div>
          <Badge className={`absolute top-3 right-3 ${getDifficultyColor(exercise.difficulty)}`}>
            {exercise.difficulty}
          </Badge>
        </div>
        
        <CardContent className="p-4">
          <h4 className="font-semibold text-slate-900 mb-2">{exercise.name}</h4>
          <div className="flex items-center space-x-2 mb-2">
            {(exercise.primaryMuscles as string[]).slice(0, 2).map((muscle) => (
              <Badge key={muscle} variant="secondary" className="text-xs">
                {muscle}
              </Badge>
            ))}
            <Badge className={`${getEquipmentColor(exercise.equipment)} text-xs`}>
              {exercise.equipment}
            </Badge>
          </div>
          <p className="text-sm text-slate-600 line-clamp-2">{exercise.description}</p>
          
          {/* Exercise Meta */}
          <div className="flex items-center justify-between mt-3 text-xs text-slate-500">
            <div className="flex items-center space-x-1">
              <Target className="h-3 w-3" />
              <span>{exercise.exerciseType}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="h-3 w-3" />
              <span>5-10 min</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
