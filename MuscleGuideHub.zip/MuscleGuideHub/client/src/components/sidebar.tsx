import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { User, UserCheck } from "lucide-react";
import type { Equipment } from "@shared/schema";

interface SidebarProps {
  selectedEquipment: string;
  onEquipmentChange: (equipment: string) => void;
}

export default function Sidebar({ selectedEquipment, onEquipmentChange }: SidebarProps) {
  const [selectedGender, setSelectedGender] = useState<"Male" | "Female">("Male");
  const [viewMode, setViewMode] = useState<"Standard" | "Advanced">("Standard");

  const { data: equipment = [] } = useQuery<Equipment[]>({
    queryKey: ["/api/equipment"],
  });

  const featuredEquipment = ["Featured", "Bodyweight", "Dumbbells", "Barbells"];
  const otherEquipment = equipment.filter(eq => !featuredEquipment.includes(eq.name));

  return (
    <aside className="w-64 bg-card dark:bg-card shadow-sm border-r border-border min-h-screen sticky top-16">
      <div className="p-6">
        {/* Gender Selector */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-foreground dark:text-foreground mb-3">Gender</h3>
          <div className="flex space-x-2">
            <Button
              variant={selectedGender === "Male" ? "default" : "outline"}
              size="sm"
              className="flex-1"
              onClick={() => setSelectedGender("Male")}
            >
              <User className="mr-2 h-4 w-4" />
              Male
            </Button>
            <Button
              variant={selectedGender === "Female" ? "default" : "outline"}
              size="sm"
              className="flex-1"
              onClick={() => setSelectedGender("Female")}
            >
              <UserCheck className="mr-2 h-4 w-4" />
              Female
            </Button>
          </div>
        </div>

        {/* View Mode */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-foreground dark:text-foreground mb-3">View Mode</h3>
          <div className="flex space-x-2">
            <Button
              variant={viewMode === "Standard" ? "default" : "outline"}
              size="sm"
              className="flex-1"
              onClick={() => setViewMode("Standard")}
            >
              Standard
            </Button>
            <Button
              variant={viewMode === "Advanced" ? "default" : "outline"}
              size="sm"
              className="flex-1 bg-[#68f169]"
              onClick={() => setViewMode("Advanced")}
            >
              Advanced
            </Button>
          </div>
        </div>

        {/* Categories */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-slate-900 mb-3">Categories</h3>
          <div className="space-y-1">
            <Button
              variant="ghost"
              className="w-full justify-start text-sm font-normal"
              onClick={() => onEquipmentChange("Featured")}
            >
              Featured
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start text-sm font-normal"
              onClick={() => onEquipmentChange("Bodyweight")}
            >
              Bodyweight
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start text-sm font-normal"
            >
              Strength Training
            </Button>
          </div>
        </div>

        {/* Equipment Filter */}
        <div>
          <h3 className="text-sm font-semibold text-slate-900 mb-3">Equipment</h3>
          <ScrollArea className="h-80">
            <div className="space-y-1">
              {/* Featured Equipment */}
              {featuredEquipment.map((equipmentName) => (
                <Button
                  key={equipmentName}
                  variant={selectedEquipment === equipmentName ? "secondary" : "ghost"}
                  className={`w-full justify-start text-sm font-normal ${
                    selectedEquipment === equipmentName 
                      ? "bg-orange-500 text-white hover:bg-orange-600" 
                      : ""
                  }`}
                  onClick={() => onEquipmentChange(equipmentName)}
                >
                  {equipmentName}
                </Button>
              ))}
              
              {/* Other Equipment */}
              {otherEquipment.map((eq) => (
                <Button
                  key={eq.id}
                  variant={selectedEquipment === eq.name ? "secondary" : "ghost"}
                  className={`w-full justify-start text-sm font-normal ${
                    selectedEquipment === eq.name 
                      ? "bg-orange-500 text-white hover:bg-orange-600" 
                      : ""
                  }`}
                  onClick={() => onEquipmentChange(eq.name)}
                >
                  {eq.name}
                </Button>
              ))}
            </div>
          </ScrollArea>
        </div>
      </div>
    </aside>
  );
}
