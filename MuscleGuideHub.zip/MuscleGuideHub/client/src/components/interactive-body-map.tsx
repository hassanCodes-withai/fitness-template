import { useState } from "react";
import { Button } from "@/components/ui/button";

interface InteractiveBodyMapProps {
  selectedMuscle: string;
  onMuscleSelect: (muscle: string) => void;
}

export default function InteractiveBodyMap({ selectedMuscle, onMuscleSelect }: InteractiveBodyMapProps) {
  const [bodyView, setBodyView] = useState<"front" | "back">("front");

  const handleMuscleClick = (muscle: string) => {
    onMuscleSelect(selectedMuscle === muscle ? "" : muscle);
  };

  return (
    <div className="flex justify-center items-center">
      <div className="relative bg-slate-50 rounded-xl p-8 border-2 border-dashed border-slate-300">
        {/* SVG Body Diagram */}
        <svg 
          width="300" 
          height="400" 
          viewBox="0 0 300 400" 
          className="mx-auto"
        >
          {bodyView === "front" ? (
            <>
              {/* Head */}
              <ellipse cx="150" cy="50" rx="30" ry="40" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="2" />
              
              {/* Chest */}
              <rect 
                x="120" 
                y="80" 
                width="60" 
                height="40" 
                rx="10" 
                className={`muscle-region muscle-chest cursor-pointer ${selectedMuscle === "Chest" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Chest")}
              />
              
              {/* Left Shoulder */}
              <circle 
                cx="100" 
                cy="90" 
                r="20" 
                className={`muscle-region muscle-shoulders cursor-pointer ${selectedMuscle === "Shoulders" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Shoulders")}
              />
              
              {/* Right Shoulder */}
              <circle 
                cx="200" 
                cy="90" 
                r="20" 
                className={`muscle-region muscle-shoulders cursor-pointer ${selectedMuscle === "Shoulders" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Shoulders")}
              />
              
              {/* Left Bicep */}
              <ellipse 
                cx="80" 
                cy="130" 
                rx="12" 
                ry="25" 
                className={`muscle-region muscle-arms cursor-pointer ${selectedMuscle === "Biceps" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Biceps")}
              />
              
              {/* Right Bicep */}
              <ellipse 
                cx="220" 
                cy="130" 
                rx="12" 
                ry="25" 
                className={`muscle-region muscle-arms cursor-pointer ${selectedMuscle === "Biceps" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Biceps")}
              />
              
              {/* Abs */}
              <rect 
                x="135" 
                y="130" 
                width="30" 
                height="60" 
                rx="5" 
                className={`muscle-region muscle-core cursor-pointer ${selectedMuscle === "Abs" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Abs")}
              />
              
              {/* Left Forearm */}
              <ellipse 
                cx="80" 
                cy="180" 
                rx="10" 
                ry="20" 
                className={`muscle-region muscle-arms cursor-pointer ${selectedMuscle === "Forearms" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Forearms")}
              />
              
              {/* Right Forearm */}
              <ellipse 
                cx="220" 
                cy="180" 
                rx="10" 
                ry="20" 
                className={`muscle-region muscle-arms cursor-pointer ${selectedMuscle === "Forearms" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Forearms")}
              />
              
              {/* Torso */}
              <rect x="120" y="120" width="60" height="80" rx="10" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="1" />
              
              {/* Left Quadriceps */}
              <ellipse 
                cx="125" 
                cy="250" 
                rx="18" 
                ry="40" 
                className={`muscle-region muscle-legs cursor-pointer ${selectedMuscle === "Quadriceps" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Quadriceps")}
              />
              
              {/* Right Quadriceps */}
              <ellipse 
                cx="175" 
                cy="250" 
                rx="18" 
                ry="40" 
                className={`muscle-region muscle-legs cursor-pointer ${selectedMuscle === "Quadriceps" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Quadriceps")}
              />
              
              {/* Left Calf */}
              <ellipse 
                cx="125" 
                cy="330" 
                rx="12" 
                ry="30" 
                className={`muscle-region muscle-legs cursor-pointer ${selectedMuscle === "Calves" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Calves")}
              />
              
              {/* Right Calf */}
              <ellipse 
                cx="175" 
                cy="330" 
                rx="12" 
                ry="30" 
                className={`muscle-region muscle-legs cursor-pointer ${selectedMuscle === "Calves" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Calves")}
              />
            </>
          ) : (
            <>
              {/* Head */}
              <ellipse cx="150" cy="50" rx="30" ry="40" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="2" />
              
              {/* Left Shoulder Back */}
              <circle 
                cx="100" 
                cy="90" 
                r="20" 
                className={`muscle-region muscle-shoulders cursor-pointer ${selectedMuscle === "Shoulders" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Shoulders")}
              />
              
              {/* Right Shoulder Back */}
              <circle 
                cx="200" 
                cy="90" 
                r="20" 
                className={`muscle-region muscle-shoulders cursor-pointer ${selectedMuscle === "Shoulders" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Shoulders")}
              />
              
              {/* Upper Back */}
              <rect 
                x="120" 
                y="80" 
                width="60" 
                height="60" 
                rx="10" 
                className={`muscle-region muscle-back cursor-pointer ${selectedMuscle === "Back" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Back")}
              />
              
              {/* Left Tricep */}
              <ellipse 
                cx="80" 
                cy="130" 
                rx="12" 
                ry="25" 
                className={`muscle-region muscle-arms cursor-pointer ${selectedMuscle === "Triceps" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Triceps")}
              />
              
              {/* Right Tricep */}
              <ellipse 
                cx="220" 
                cy="130" 
                rx="12" 
                ry="25" 
                className={`muscle-region muscle-arms cursor-pointer ${selectedMuscle === "Triceps" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Triceps")}
              />
              
              {/* Lower Back */}
              <rect 
                x="125" 
                y="150" 
                width="50" 
                height="40" 
                rx="5" 
                className={`muscle-region muscle-back cursor-pointer ${selectedMuscle === "Back" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Back")}
              />
              
              {/* Glutes */}
              <ellipse 
                cx="150" 
                cy="210" 
                rx="35" 
                ry="25" 
                className={`muscle-region muscle-legs cursor-pointer ${selectedMuscle === "Glutes" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Glutes")}
              />
              
              {/* Left Hamstring */}
              <ellipse 
                cx="125" 
                cy="270" 
                rx="18" 
                ry="35" 
                className={`muscle-region muscle-legs cursor-pointer ${selectedMuscle === "Hamstrings" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Hamstrings")}
              />
              
              {/* Right Hamstring */}
              <ellipse 
                cx="175" 
                cy="270" 
                rx="18" 
                ry="35" 
                className={`muscle-region muscle-legs cursor-pointer ${selectedMuscle === "Hamstrings" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Hamstrings")}
              />
              
              {/* Left Calf Back */}
              <ellipse 
                cx="125" 
                cy="330" 
                rx="12" 
                ry="30" 
                className={`muscle-region muscle-legs cursor-pointer ${selectedMuscle === "Calves" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Calves")}
              />
              
              {/* Right Calf Back */}
              <ellipse 
                cx="175" 
                cy="330" 
                rx="12" 
                ry="30" 
                className={`muscle-region muscle-legs cursor-pointer ${selectedMuscle === "Calves" ? "active" : ""}`}
                onClick={() => handleMuscleClick("Calves")}
              />
            </>
          )}
        </svg>
        
        {/* Body View Toggle */}
        <div className="flex justify-center space-x-2 mt-6">
          <Button
            variant={bodyView === "front" ? "default" : "outline"}
            size="sm"
            onClick={() => setBodyView("front")}
          >
            Front
          </Button>
          <Button
            variant={bodyView === "back" ? "default" : "outline"}
            size="sm"
            onClick={() => setBodyView("back")}
          >
            Back
          </Button>
        </div>
      </div>
    </div>
  );
}
